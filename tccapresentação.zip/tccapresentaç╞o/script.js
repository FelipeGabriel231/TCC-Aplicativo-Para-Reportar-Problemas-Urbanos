// Função para controlar a troca de abas
function openTab(evt, tabName) {
    // Esconde todos os conteúdos das abas
    const tabcontent = document.getElementsByClassName("tab-content");
    for (let i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    // Remove a classe "active" de todos os botões de aba
    const tablinks = document.getElementsByClassName("tab-link");
    for (let i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }

    // Mostra a aba selecionada e adiciona a classe "active" ao botão
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
}

// Função para controlar a visibilidade da senha
document.addEventListener('DOMContentLoaded', () => {
    const visibilityIcons = document.querySelectorAll('.visibility-icon');
    
    visibilityIcons.forEach(icon => {
        icon.addEventListener('click', () => {
            const passwordInput = icon.previousElementSibling;
            if (passwordInput.type === "password") {
                passwordInput.type = "text";
                icon.textContent = "visibility";
            } else {
                passwordInput.type = "password";
                icon.textContent = "visibility_off";
            }
        });
    });
});