// Arquivo: firebase-client.js
// VERSÃO ATUALIZADA: Adicionada a função 'removeReportPriority'.

// 1. CONFIGURAÇÃO DO FIREBASE
const firebaseConfig = {
  apiKey: "AIzaSyD7uDtVBzFj_a9HMn-mtihE2VrJXrab918",
  authDomain: "mogi-resolve-app-8b5ae.firebaseapp.com",
  projectId: "mogi-resolve-app-8b5ae",
  storageBucket: "mogi-resolve-app-8b5ae.firebasestorage.app",
  messagingSenderId: "185867558631",
  appId: "1:185867558631:web:dd474c942bbdc98bf28c42"
};

// 2. INICIALIZAÇÃO E ATALHOS
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();
const storage = firebase.storage();

// 3. CLASSE DE AUTENTICAÇÃO
class FirebaseAuth {

    /**
     * Registra um novo usuário (cidadão ou prefeitura).
     */
    async register({ name, email, password, prefCode }) {
        const userCredential = await auth.createUserWithEmailAndPassword(email, password);
        const user = userCredential.user;
        await user.sendEmailVerification();
        await user.updateProfile({ displayName: name });
        const role = (prefCode && prefCode.trim() === '123456') ? 'prefeitura' : 'cidadao';
        await db.collection('users').doc(user.uid).set({
            name, email, role,
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        await auth.signOut();
        return { name: user.displayName, role };
    }

    /**
     * Faz o login de um CIDADÃO.
     */
    async login({ email, password }) {
        const userCredential = await auth.signInWithEmailAndPassword(email, password);
        const user = userCredential.user;
        if (!user.emailVerified) {
            await user.sendEmailVerification();
            await auth.signOut();
            throw new Error("Seu e-mail não foi verificado. Um novo link de verificação foi enviado.");
        }
        const userDoc = await db.collection('users').doc(user.uid).get();
        if (!userDoc.exists) throw new Error("Dados de perfil não encontrados.");
        const userData = userDoc.data();
        return { 
            id: user.uid, name: user.displayName, email: user.email, role: userData.role
        };
    }

    /**
     * Faz o login de um ADMINISTRADOR.
     */
    async loginAdmin({ email, password, prefCode }) {
        if (!prefCode || prefCode.trim() !== '123456') {
            throw new Error("Código de Acesso incorreto.");
        }
        const userCredential = await auth.signInWithEmailAndPassword(email, password);
        const user = userCredential.user;
        if (!user.emailVerified) {
            await user.sendEmailVerification();
            await auth.signOut();
            throw new Error("Seu e-mail não foi verificado. Um novo link foi enviado.");
        }
        const userDoc = await db.collection('users').doc(user.uid).get();
        if (!userDoc.exists) throw new Error("Dados de perfil não encontrados.");
        const userData = userDoc.data();
        if (userData.role !== 'prefeitura') {
            await auth.signOut();
            throw new Error("Este usuário não tem permissão de administrador.");
        }
        return { 
            id: user.uid, name: user.displayName, email: user.email, role: userData.role
        };
    }
    
    /**
     * Envia um e-mail de redefinição de senha.
     */
    async resetPassword({ email }) {
        if (!email) {
            throw new Error("O campo de e-mail não pode estar vazio.");
        }
        await auth.sendPasswordResetEmail(email);
        return true;
    }

    /**
     * Desloga o usuário atual.
     */
    logout() {
        return auth.signOut();
    }

    /**
     * Pega os dados do usuário logado no momento.
     */
    async currentUser() {
        const user = auth.currentUser;
        if (!user) {
            return null;
        }
        const userDoc = await db.collection('users').doc(user.uid).get();
        if (!userDoc.exists) {
            console.warn("Usuário autenticado, mas sem perfil no Firestore.");
            return { id: user.uid, name: user.displayName, email: user.email, role: 'cidadao' };
        }
        const profileData = userDoc.data();
        return { 
            id: user.uid, name: user.displayName, email: user.email, 
            photoURL: user.photoURL, role: profileData.role
        };
    }
    
    // ====================================================================== //
    // --- FUNÇÕES DO SISTEMA DE ENVIO E RECEBIMENTO DE RELATÓRIOS --- //
    // ====================================================================== //

    /**
     * Cidadão envia um novo relatório.
     */
    async sendReport(title, description, category, file) {
        const user = await this.currentUser();
        if (!user) throw new Error('Usuário não autenticado.');
        
        let fileUrl = null;
        if (file) {
            const filePath = `reports/${user.id}/${Date.now()}_${file.name}`;
            const fileRef = storage.ref(filePath);
            await fileRef.put(file);
            fileUrl = await fileRef.getDownloadURL();
        }

        return db.collection('reports').add({
            title,
            description,
            category,
            fileUrl: fileUrl || null,
            authorId: user.id,
            authorName: user.name,
            createdAt: firebase.firestore.FieldValue.serverTimestamp(),
            status: 'aberto',
            priority: null,
            isResolved: false,
            prefeituraComment: null,
            respondedAt: null
        });
    }

    /**
     * Prefeitura busca todos os relatórios.
     */
    async getAllReports() {
        const snapshot = await db.collection('reports').orderBy('createdAt', 'desc').get();
        return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    }

    /**
     * Cidadão busca apenas os seus próprios relatórios.
     */
    async getUserReports() {
        const user = await this.currentUser();
        if (!user) return [];

        const snapshot = await db.collection('reports')
            .where('authorId', '==', user.id)
            .orderBy('createdAt', 'desc')
            .get();
        return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    }

    /**
     * Prefeitura responde a um relatório.
     */
    async respondToReport(reportId, { priority, isResolved, comment }) {
        const reportRef = db.collection('reports').doc(reportId);
        
        return reportRef.update({
            priority,
            isResolved,
            prefeituraComment: comment,
            status: 'respondido',
            respondedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    }

    /**
     * Prefeitura atualiza apenas a prioridade de um relatório.
     */
    async updateReportPriority(reportId, priority) {
        if (!reportId || !priority) {
            throw new Error("ID do relatório e prioridade são obrigatórios.");
        }
        const reportRef = db.collection('reports').doc(reportId);
        return reportRef.update({
            priority: priority
        });
    }
    
    // ====================================================================== //
    // --- ATENÇÃO: FUNCIONALIDADE DE REMOVER PRIORIDADE ADICIONADA AQUI --- //
    // ====================================================================== //
    
    /**
     * Prefeitura remove a prioridade de um relatório.
     */
    async removeReportPriority(reportId) {
        if (!reportId) {
            throw new Error("ID do relatório é obrigatório.");
        }
        const reportRef = db.collection('reports').doc(reportId);
        return reportRef.update({
            priority: null
        });
    }


    /**
     * Busca um relatório específico pelo ID.
     */
    async getReportById(reportId) {
        const doc = await db.collection('reports').doc(reportId).get();
        if (!doc.exists) return null;
        return { id: doc.id, ...doc.data() };
    }

    // ====================================================================== //
    // --- MÉTODOS DE PERFIL --- //
    // ====================================================================== //
    
    /**
     * Atualiza a foto de perfil do usuário.
     */
    async updateUserProfilePicture(userId, imageFile) {
        const filePath = `profile_pictures/${userId}`;
        const fileRef = storage.ref(filePath);
        await fileRef.put(imageFile);
        const photoURL = await fileRef.getDownloadURL();
        await auth.currentUser.updateProfile({ photoURL: photoURL });
        await db.collection('users').doc(userId).update({ profilePictureUrl: photoURL });
        return true;
    }
    
    /**
     * Atualiza o nome de exibição do usuário no Firebase Auth e no Firestore.
     */
    async updateDisplayName(newName) {
        const user = auth.currentUser;
        if (!user) throw new Error("Usuário não autenticado.");
        
        // 1. Atualiza o perfil no Firebase Authentication
        await user.updateProfile({
            displayName: newName
        });
        
        // 2. Atualiza o nome no documento do usuário no Firestore
        return db.collection('users').doc(user.uid).update({
            name: newName
        });
    }
}

// Expõe a classe para ser usada globalmente por todas as páginas HTML
window.Auth = new FirebaseAuth();