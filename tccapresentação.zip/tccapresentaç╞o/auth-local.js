/**
 * auth-local.js - vFINAL
 * Sistema completo de autenticação e gerenciamento de dados locais.
 * - Usa localStorage para dados de usuários (login/sessão) com Hashing SHA-256 para senhas.
 * - Usa IndexedDB (via Dexie.js) para armazenar relatórios e perfis (fotos), evitando erros de "quota".
 */
class LocalAuth {
    constructor() {
        this.keys = { USERS: 'users_v5_secure', SESSION: 'session_v5_secure' };
        
        this.db = new Dexie("MogiResolveAppDB_v3");
        this.db.version(2).stores({
            reports: 'id, authorId, createdAt, title, description, category',
            userProfiles: 'userId'
        });

        this._initDefaultUsers();
    }

    // --- Métodos Privados ---
    _get(key) { return JSON.parse(localStorage.getItem(key) || '[]'); }
    _set(key, value) { localStorage.setItem(key, JSON.stringify(value)); }
    _uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }

    async _hashPassword(password) {
        const data = new TextEncoder().encode(password);
        const hashBuffer = await crypto.subtle.digest('SHA-256', data);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    }

    async _initDefaultUsers() {
        if (this._get(this.keys.USERS).length > 0) return;
        const adminPasswordHash = await this._hashPassword('pref1234');
        const userPasswordHash = await this._hashPassword('123456');
        const defaultUsers = [
            { id: this._uid(), name: "Prefeitura Admin", email: "prefeitura@cidade.gov", passwordHash: adminPasswordHash, role: "prefeitura" },
            { id: this._uid(), name: "Cidadão Comum", email: "user@demo.com", passwordHash: userPasswordHash, role: "user" }
        ];
        this._set(this.keys.USERS, defaultUsers);
    }
    
    _createSession(user) {
        const sessionData = { id: user.id, name: user.name, email: user.email, role: user.role };
        this._set(this.keys.SESSION, sessionData);
        return sessionData;
    }

    // --- Métodos de Autenticação ---
    async register({ name, email, password, confirmPassword, prefCode }) {
        if (!name || !email || !password || !confirmPassword) throw new Error("Todos os campos são obrigatórios.");
        if (password !== confirmPassword) throw new Error("As senhas não coincidem.");
        if (password.length < 6) throw new Error("A senha deve ter no mínimo 6 caracteres.");
        const users = this._get(this.keys.USERS);
        if (users.find(u => u.email.toLowerCase() === email.toLowerCase())) throw new Error("Este email já está cadastrado.");
        const passwordHash = await this._hashPassword(password);
        const role = (prefCode && prefCode.trim().toUpperCase() === 'PREF-CODE-1234') ? 'prefeitura' : 'user';
        const newUser = { id: this._uid(), name, email, passwordHash, role };
        users.push(newUser);
        this._set(this.keys.USERS, users);
        return { name: newUser.name, role: newUser.role };
    }

    async login({ email, password }) {
        const users = this._get(this.keys.USERS);
        const userFound = users.find(u => u.email.toLowerCase() === email.toLowerCase());
        if (!userFound) throw new Error("Email ou senha inválidos.");
        const inputPasswordHash = await this._hashPassword(password);
        if (inputPasswordHash !== userFound.passwordHash) throw new Error("Email ou senha inválidos.");
        return this._createSession(userFound);
    }

    currentUser() { return this._get(this.keys.SESSION); }
    logout() { localStorage.removeItem(this.keys.SESSION); }

    // --- Métodos de Relatórios ---
    async createReport(reportData) {
        const user = this.currentUser();
        if (!user) throw new Error('Você precisa estar logado para criar um relatório.');
        const fullReport = { ...reportData, id: this._uid(), authorId: user.id, authorName: user.name, priority: 'low', status: 'aberto', createdAt: new Date().toISOString(), comments: [] };
        await this.db.reports.add(fullReport);
        return fullReport;
    }

    async getAllReports() { return await this.db.reports.orderBy('createdAt').reverse().toArray(); }
    async getReportById(reportId) { return await this.db.reports.where({ id: reportId }).first(); }

    // --- Métodos de Perfil ---
    async getUserProfile(userId) {
        if (!userId) return null;
        return await this.db.userProfiles.get(userId);
    }
    
    async updateUserProfilePicture(userId, imageFile) {
        if (!userId || !imageFile) throw new Error("Dados inválidos para atualizar a foto.");
        await this.db.userProfiles.put({ userId, profilePicture: imageFile });
        return true;
    }

    async removeUserProfilePicture(userId) {
        if (!userId) return false;
        await this.db.userProfiles.delete(userId);
        return true;
    }

    async updateUserName(userId, newName) {
        if (!newName || newName.trim().length < 3) throw new Error("O nome deve ter pelo menos 3 caracteres.");
        const users = this._get(this.keys.USERS);
        const userIndex = users.findIndex(u => u.id === userId);
        if (userIndex > -1) {
            users[userIndex].name = newName.trim();
            this._set(this.keys.USERS, users);
            const session = this.currentUser();
            if (session && session.id === userId) {
                session.name = newName.trim();
                this._set(this.keys.SESSION, session);
            }
            return true;
        }
        throw new Error("Usuário não encontrado.");
    }

    async updateUserPassword({ userId, oldPassword, newPassword, confirmPassword }) {
        if (!oldPassword || !newPassword || !confirmPassword) throw new Error("Todos os campos de senha são obrigatórios.");
        if (newPassword !== confirmPassword) throw new Error("A nova senha e a confirmação não coincidem.");
        if (newPassword.length < 6) throw new Error("A nova senha deve ter no mínimo 6 caracteres.");
        const users = this._get(this.keys.USERS);
        const user = users.find(u => u.id === userId);
        if (!user) throw new Error("Usuário não encontrado.");
        const oldPasswordHash = await this._hashPassword(oldPassword);
        if (oldPasswordHash !== user.passwordHash) throw new Error("A senha antiga está incorreta.");
        user.passwordHash = await this._hashPassword(newPassword);
        this._set(this.keys.USERS, users);
        return true;
    }
    
    // --- Função de Comunicados ---
    getComunicados() {
        // ... (código existente)
        return []; // Retornando vazio conforme solicitado
    }
}
window.Auth = new LocalAuth();